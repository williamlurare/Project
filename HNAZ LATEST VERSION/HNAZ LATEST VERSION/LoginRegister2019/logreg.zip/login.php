
<!doctype html>
<html>
<head>
<title>login</title>
</head>
<body>
	<form method="POST" action="validate.php">
Student ID: <input type= "text" name="id" /><br />
Password: <input type= "text" name="password" /></br />
<input type="submit" value="Login"><br />
<br />
<br /><a href="Register.php">Register</a><br />
</form>
</body>
</html>